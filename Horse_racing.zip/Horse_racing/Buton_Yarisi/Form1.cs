﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Buton_Yarisi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button_yaris_1.Click += Button_yaris_1_Click;
            button_yaris_2.Click += Button_yaris_2_Click;
            button_yaris_3.Click += Button_yaris_3_Click;
        }



        // Când selectați un concurent, tipăriți-l pe etichetă pe cel selectat
        private void Button_yaris_1_Click(object sender, EventArgs e)
        {
            label1.Text = "1 Numar";
        }

        private void Button_yaris_2_Click(object sender, EventArgs e)
        {
            label1.Text = "2 Numar";
        }

        private void Button_yaris_3_Click(object sender, EventArgs e)
        {
            label1.Text = "3 Numar";
        }

        Random rnd = new Random();
        int btn1x,btn1y,btn2x,btn2y,btn3x,btn3y;// Obțineți punctele de pornire ale concurenților

        mesajver mesaj = new mesajver(); // Class mesaje

        private void old_location() //Obțineți punctele de pornire ale concurenților
        {
            button_yaris_1.Location = new Point(btn1x, btn1y);
            button_yaris_2.Location = new Point(btn2x, btn2y);
            button_yaris_3.Location = new Point(btn3x, btn3y);
            button1.Enabled = true;
            button_yaris_1.Enabled = true;
            button_yaris_2.Enabled = true;
            button_yaris_3.Enabled = true;
            label1.Text = "";
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            int konum1 = rnd.Next(2, 10);//Un număr aleatoriu pentru fiecare concurent si locatie 
            int konum2 = rnd.Next(2, 10);
            int konum3 = rnd.Next(2, 10);
            if (button_yaris_1.Right > label_bitis.Left || button_yaris_2.Right > label_bitis.Left || button_yaris_2.Right > label_bitis.Left)
            {// Dacă unul dintre concurenți este la linia de sosire, adică cursa s-a încheiat.
                if (button_yaris_1.Right > button_yaris_2.Right && button_yaris_1.Right > button_yaris_3.Right)
                { // Dacă concurentul 1 este înaintea celorlalți
                    if (label1.Text == "1 Numar")//daca alegem numarul unu si spunem ca o sa vii primul
                    {
                        timer1.Stop();// atunci cursa sa incheie
                        mesaj.mesajgetir("congrats correct guess.");// si dupa afiseaza mesajul felicitari alegerea ta este corect
                        old_location();
                    }
                    else
                    {
                        timer1.Stop();
                        mesaj.mesajgetir("The horse you chose did not come. Winner Number 1.");
                        old_location();
                    }

                }
                else if (button_yaris_2.Right > button_yaris_1.Right && button_yaris_2.Right > button_yaris_3.Right)
                {// If competitor 2 is ahead of the others
                    if (label1.Text == "2 Numar")
                    {
                        timer1.Stop();
                        mesaj.mesajgetir("congrats correct guess.");
                        old_location();
                    }
                    else
                    {
                        timer1.Stop();
                        mesaj.mesajgetir("The horse you chose did not come. Winner Number 2.");
                        old_location();
                    }
                }
                else if (button_yaris_3.Right > button_yaris_1.Right && button_yaris_3.Right > button_yaris_2.Right)
                {// If competitor 3 is ahead of the others
                    if (label1.Text == "3 Numar")
                    {
                        timer1.Stop();
                        mesaj.mesajgetir("congrats correct guess.");
                        old_location();
                    }
                    else
                    {
                        timer1.Stop();
                        mesaj.mesajgetir("The horse you chose did not come. Winner Number 2.");
                        old_location();
                    }
                }
                else { timer1.Stop(); old_location(); }
            }
            else
            {// Dacă unul dintre călăreți nu este la linia de sosire, avansați pe fiecare spre dreapta cu numere aleatorii, deci dacă cursa nu s-a terminat
                button_yaris_1.Location = new Point(button_yaris_1.Location.X + konum1, button_yaris_1.Location.Y);
                button_yaris_2.Location = new Point(button_yaris_2.Location.X + konum2, button_yaris_2.Location.Y);
                button_yaris_3.Location = new Point(button_yaris_3.Location.X + konum3, button_yaris_3.Location.Y);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            btn1x = button_yaris_1.Location.X; //Pozițiile de start ale concurenților
            btn1y = button_yaris_1.Location.Y;
            btn2x = button_yaris_2.Location.X;
            btn2y = button_yaris_2.Location.Y;
            btn3x = button_yaris_3.Location.X;
            btn3y = button_yaris_3.Location.Y;
            if (label1.Text == "" || label1.Text == "Te rog alege calul.") //Dacă calul nu este selectat
            {
                label1.Text = ("Te rog alege calul.");
            }
            else
            { // dacă calul este selectat acum, închideți selecțiile începe cursa
                button_yaris_1.Enabled = false;
                button_yaris_2.Enabled = false;
                button_yaris_3.Enabled = false;
                button1.Enabled = false;
                timer1.Start();
            }
        }
    }
}
